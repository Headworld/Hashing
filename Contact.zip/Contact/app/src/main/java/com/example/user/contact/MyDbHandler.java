package com.example.user.contact;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteCursor;
import android.content.Context;
import android.content.ContentValues;


public class MyDbHandler extends SQLiteOpenHelper {

    // I create my Database, Database Version, tables and columns

    private static final int DatabaseVersion = 1;
    private static final String DatabaseName = "products.db";
    public static final String TableProduct = "product";

    public static final String ColumnId = "_id";
    public static final String ColumnProduct = "productName";

    // I am using Handler to parse my database  and its version

    public MyDbHandler(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DatabaseName, factory, DatabaseVersion);
    }

    //Head is creating my query here, + sign here mean concatenation
    @Override
    public void onCreate(SQLiteDatabase db) {

        String query = "Create Table"+TableProduct +" ("+
                ColumnId + "INTEGER PRIMARY KEY AUTOINCREMENT "+
                ColumnProduct + " TEXT "+
                ");";
        db.execSQL(query);  // I execute Create Query Here

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {


    }

    // adding value to database
    public void addProduct(Products product){
        ContentValues values = new ContentValues();
        values.put(ColumnProduct,product.get_productName());
        SQLiteDatabase db = getWritableDatabase();
        db.insert(TableProduct, null, values);
        db.close();
    }
    //deleting value from database
    public void delete(String columnProduct){
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("DELETE FROM "+TableProduct+"WHERE "+ColumnProduct +"=\""+columnProduct+"\";");
    }

    //Outputting the results

    public String databaseResult(){
        String dbstring = " ";
        SQLiteDatabase db = getWritableDatabase();
        String query = "SELECT * FROM "+TableProduct+"WHERE = 1";
        Cursor c = db.rawQuery(query,null);
        c.moveToFirst();

        while (!c.isAfterLast()){
            if(c.getString(c.getColumnIndex("productName"))!=null){
               dbstring += c.getString(c.getColumnIndex("productName"));
                dbstring +="\n";
            }
        }
        db.close();
        return dbstring;

    }
}
