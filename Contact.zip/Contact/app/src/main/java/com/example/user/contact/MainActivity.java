package com.example.user.contact;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText edt;
    TextView txw;
    MyDbHandler mdh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edt = (EditText)findViewById(R.id.editText);
        txw = (TextView)findViewById(R.id.textView);
         mdh = new MyDbHandler(this,null,null,1);
        printdatabase();
    }

    // add product to database

    public void add(View view)
    {
        Products product = new Products(txw.getText().toString());
        mdh.addProduct(product);
        printdatabase();
    }

    //delete from database
    public void delete(View v)
    {
        String a = txw.getText().toString();
        mdh.delete(a);
        printdatabase();
    }


    public void printdatabase(){
        String dbString = mdh.databaseResult();
        txw.setText(dbString);
        edt.setText(" ");
    }
}
